using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using StudentMvc.Models;
using StudentMvc.Services;

namespace StudentMvc.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentService _studentService;
        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }
        public IActionResult Index()
        {
            List<Student> students = _studentService.GetStudents();

            ViewData["Students"] = students;
            ViewBag.Students = students;
            
            return View(students);
        }

        public IActionResult Add()
        {
            return View();
        }

        public IActionResult Edit(int studentId)
        {
            var student = _studentService.GetStudentById(studentId);
            return View(student);
        }

        public IActionResult Delete(int studentId)
        {
            _studentService.DeleteStudent(studentId);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult SaveStudent([FromForm] Student student)
        {
            if (student.StudentId == 0)
            {
                _studentService.AddNewStudent(student);
            }
            _studentService.UpdateStudent(student);
            return RedirectToAction("Index");
        }
    }
}