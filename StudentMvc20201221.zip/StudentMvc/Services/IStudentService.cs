using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentMvc.Models;

namespace StudentMvc.Services
{
    public interface IStudentService
    {
        public List<Student> GetStudents();
        public Student GetStudentById(int studentId);
        public Student AddNewStudent(Student studentInput);
        public Student UpdateStudent(Student studentInput);
        public bool DeleteStudent(int studentId);
    }
}