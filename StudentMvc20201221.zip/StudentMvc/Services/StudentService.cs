using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentMvc.Models;

namespace StudentMvc.Services
{
    public class StudentService : IStudentService
    {
        private readonly DataContext _context;
        public StudentService(DataContext context)
        {
            _context = context;
        }

        public Student AddNewStudent(Student studentInput)
        {
            _context.Add(studentInput);
            _context.SaveChanges();
            return studentInput;
        }

        public bool DeleteStudent(int studentId)
        {
            var student = GetStudentById(studentId);
            _context.Remove(student);
            _context.SaveChanges();
            return true;
        }

        public Student GetStudentById(int studentId)
        {
            return _context.Students.FirstOrDefault(s => s.StudentId == studentId);
        }

        public List<Student> GetStudents()
        {
            return _context.Students.ToList();
        }

        public Student UpdateStudent(Student studentInput)
        {
            var student = GetStudentById(studentInput.StudentId);
            student.Name = studentInput.Name;
            student.Age = studentInput.Age;
            _context.SaveChanges();
            return student;
        }
    }
}